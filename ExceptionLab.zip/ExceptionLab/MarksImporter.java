import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Custom unchecked exception to signal duplicate student identifiers.
 */
class DuplicateStudentException extends RuntimeException {
    public DuplicateStudentException(String message) {
        super(message);
    }
}

public class MarksImporter {
    
    // Logger to capture technical details for developers/system administrators
    private static final Logger LOGGER = Logger.getLogger(MarksImporter.class.getName());

    /**
     * Reads and processes student marks from a specified text file.
     * 
     * @param filename Path to the input file
     * @throws IOException If a critical file access/reading error occurs
     */
    static void importMarks(String filename) throws IOException {
        Set<String> seen = new HashSet<>();
        
        // Try-with-resources: AutoCloseable guarantees BufferedReader is closed automatically
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            int lineNumber = 0;

            while ((line = br.readLine()) != null) {
                lineNumber++;
                
                // Skip empty lines safely
                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] parts = line.split(",");

                // TODO 1: Check there are exactly 2 fields
                if (parts.length != 2) {
                    LOGGER.log(Level.WARNING, "Line {0}: Malformed record (expected 2 fields, found {1}) -> ''{2}''", 
                            new Object[]{lineNumber, parts.length, line});
                    System.out.println("⚠️ Record skipped: Line " + lineNumber + " does not contain exactly two fields.");
                    continue;
                }

                String studentId = parts[0].trim();
                String rawMark = parts[1].trim();

                try {
                    // TODO 2: Parse mark and validate range 0..100
                    int mark;
                    try {
                        mark = Integer.parseInt(rawMark);
                    } catch (NumberFormatException e) {
                        throw new NumberFormatException("Non-numeric mark encountered: '" + rawMark + "'");
                    }

                    if (mark < 0 || mark > 100) {
                        throw new IllegalArgumentException("Mark (" + mark + ") is out of valid range 0..100");
                    }

                    // TODO 3: Detect repeated student ID using set lookup
                    if (!seen.add(studentId)) {
                        throw new DuplicateStudentException("Duplicate record found for student ID: " + studentId);
                    }

                    // TODO 4: Display accepted record
                    System.out.println("✅ Accepted: ID = " + studentId + ", Mark = " + mark);

                } catch (NumberFormatException e) {
                    LOGGER.log(Level.WARNING, "Line " + lineNumber + " [Parse Error]: " + e.getMessage(), e);
                    System.out.println("❌ Invalid numeric mark reported safely for " + studentId + " (value: '" + rawMark + "')");
                } catch (IllegalArgumentException e) {
                    LOGGER.log(Level.WARNING, "Line " + lineNumber + " [Validation Error]: " + e.getMessage(), e);
                    System.out.println("❌ Out-of-range mark rejected for " + studentId + " (value: " + rawMark + ")");
                } catch (DuplicateStudentException e) {
                    LOGGER.log(Level.WARNING, "Line " + lineNumber + " [Duplicate Error]: " + e.getMessage(), e);
                    System.out.println("🔁 Duplicate student ID identified: " + studentId);
                }
            }
        }
    }

    public static void main(String[] args) {
        // Activity C: Outer execution block with friendly messaging and logging
        try {
            importMarks("marks.txt");
        } catch (FileNotFoundException e) {
            LOGGER.log(Level.SEVERE, "Target file could not be found", e);
            System.out.println("📁 Marks file not found; check the file name.");
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Input/Output reading error occurred", e);
            System.out.println("⚠️ An error occurred while reading the marks file.");
        } finally {
            // Guarantees execution regardless of pass or fail outcome
            System.out.println("Import attempt finished");
        }
    }
}
